SELECT * FROM customers;

# How many customers we have?
SELECT COUNT(*) AS Total_customers FROM customers;

# What is the Total Credit Limit?
SELECT SUM(creditLimit) AS Total_Credit_Limit FROM customers;

# What is the average credit limit?
SELECT AVG(creditLimit) AS Average_Credit_Limit FROM customers;

# What is the Maximum Credit Limit?
SELECT MAX(creditLimit) AS Maximum_Credit_Limit FROM customers;

# What is the Minimum Credit Limit?
SELECT MIN(creditLimit) AS Minimum_Credit_Limit FROM customers;

# clauses - to retrive, filter, sort, arange, organise we use clauses
SELECT * FROM customers
WHERE country = 'Poland';

SELECT * FROM customers
WHERE country = 'Poland' OR country = "USA";

SELECT * FROM customers
WHERE country = 'Poland' AND country = "USA";

SELECT * FROM customers;

SELECT * FROM customers
WHERE country = 'Poland' OR country = "USA" OR country = "France";

SELECT * FROM customers
WHERE country IN ("Poland","USA","France");

SELECT * FROM customers
WHERE country NOT IN ("Poland","USA","France");

# Get the total Creditlimit of countries
SELECT country,SUM(creditLimit) FROM Customers
GROUP BY country;

SELECT country,SUM(creditLimit) FROM Customers
GROUP BY country
ORDER BY country DESC;

SELECT country,SUM(creditLimit) AS Total_Credit_Limit FROM Customers
GROUP BY country
ORDER BY Total_Credit_Limit DESC;

SELECT country,SUM(creditLimit) AS Total_Credit_Limit FROM Customers
GROUP BY country
HAVING Total_Credit_Limit > 500000
ORDER BY Total_Credit_Limit DESC;

SELECT country,SUM(creditLimit) AS Total_Credit_Limit FROM Customers
WHERE country IN ("USA","Spain")
GROUP BY country
HAVING Total_Credit_Limit > 500000
ORDER BY Total_Credit_Limit DESC;

SELECT * FROM customers;

# WHERE clause is to filter the individual records, u should use before GROUP BY function.

# HAVING clause is to filter group of records, so u should use after GROUP BY if you want
# to filter the records.

SELECT country,SUM(creditLimit) AS Total_Credit_Limit FROM Customers
GROUP BY country
ORDER BY Total_Credit_Limit DESC
LIMIT 5;

SELECT country,SUM(creditLimit) AS Total_Credit_Limit FROM Customers
GROUP BY country
ORDER BY Total_Credit_Limit DESC
LIMIT 0,5;   # After 0th record, give me 5 records




SELECT country,SUM(creditLimit) AS Total_Credit_Limit FROM Customers
WHERE country LIKE "A%"  # First character should be "A".
GROUP BY country
ORDER BY Total_Credit_Limit DESC;

SELECT country,SUM(creditLimit) AS Total_Credit_Limit FROM Customers
WHERE country LIKE "%A"  # Last character should be "A".
GROUP BY country
ORDER BY Total_Credit_Limit DESC;

SELECT country,SUM(creditLimit) AS Total_Credit_Limit FROM Customers
WHERE country LIKE "C%A"  # First char should be "C", Last character should be "A".
GROUP BY country
ORDER BY Total_Credit_Limit DESC;

SELECT country,SUM(creditLimit) AS Total_Credit_Limit FROM Customers
WHERE country LIKE "%land%"  # country should contain land in it.
GROUP BY country
ORDER BY Total_Credit_Limit DESC;

SELECT country,SUM(creditLimit) AS Total_Credit_Limit FROM Customers
WHERE country LIKE "%lands"  # Ends with "lands"
GROUP BY country
ORDER BY Total_Credit_Limit DESC;

SELECT customerName,creditLimit FROM customers
WHERE creditLimit BETWEEN 10000 AND 20000;

SELECT customerName,creditLimit FROM customers
WHERE creditLimit BETWEEN 10000 AND 25000;



