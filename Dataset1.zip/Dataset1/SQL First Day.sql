# Create a Database --> DataMites
CREATE DATABASE DataMites;  # Using this statement, u will create the database

# Dropping the Database --> datamites
DROP DATABASE datamites;  # Using this statement, u will drop the database.
 
# Creating the table (Defining structure of the table in the DB)-->
CREATE TABLE Student_details(
Student_ID INT, 
NAME VARCHAR(50), 
Marks INT
);

# Selecting the table from the database
SELECT * FROM student_details;   # Here * means all the columns

# Inserting the records(values) in the table - inserting only one record.
INSERT INTO student_details VALUES
(1,"A",95);

# To make the computer to use particular database:
USE Datamites;

# Inserting multiple records(values) at a time
INSERT INTO student_details VALUES
(2,"B",85),
(3,"C",68),
(4,"D",75);   # Using this statement we are entering 3 records at a time

SELECT * FROM student_details;

# Convert the Student_ID column as Primary key
ALTER TABLE student_details
MODIFY Student_ID INT PRIMARY KEY;

SELECT * FROM Student_details;

SELECT Student_ID FROM student_details;  # Selecting only one column from the table - Student_ID

SELECT Student_ID,Marks FROM student_details; # Selecting two columns

SELECT Marks,Student_ID FROM student_details; # Selecting two columns

SELECT * FROM Student_details;

# To get information of structure of the table: 
# Structure of table - Table name, Column names, datatypes, and constraints
DESCRIBE student_details;

# Creating duplicate student_details table
CREATE TABLE Duplicate_Student_Details AS SELECT * FROM student_details;

SELECT * FROM student_details;

# Deleting the record which belongs to Student C:
DELETE FROM student_details
WHERE Name = "C";  

DELETE FROM Student_details
WHERE Marks = 95 OR Marks = 75; 

SELECT * FROM Student_details;

DROP TABLE Student_details; # To delete entire table including structure of the table from
							# Database
                            
SELECT * FROM duplicate_student_details;

# Creating Student_details table again :
CREATE TABLE Student_details AS SELECT * FROM duplicate_student_details;

SELECT * FROM student_details;

# To delete all the records at a time from the table:
TRUNCATE TABLE student_details;
TRUNCATE Student_details;
DELETE FROM student_details;  # Use DELETE command without WHERE clause


# DELETE and TRUNCATE commands are only deals with records
# Column is part of structure of table - so to deal with structure 
# of the table you should use ALTER command

SELECT * FROM student_details;

DROP TABLE student_details;

CREATE TABLE Student_details AS SELECT * FROM duplicate_student_details;

SELECT * FROM Student_details;

# Renaming the table name from student_details(Current name) to students(New Name)
ALTER TABLE student_details
RENAME TO Students;

DESCRIBE Students;

# Changing the datatype of the Marks column
ALTER TABLE students
MODIFY Marks FLOAT;

SELECT * FROM students;
# Adding a new column "City" to students table
ALTER TABLE students
ADD City VARCHAR(20);

ALTER TABLE students
ADD State VARCHAR(20);

# Change column name from Student_ID to Role_No
ALTER TABLE Students
CHANGE COLUMN Student_ID Role_No INT PRIMARY KEY;

SELECT * FROM students;

# Deleting the State column
ALTER TABLE Students
DROP State;

# Update city as Bengaluru for Student B 
UPDATE Students
SET City = "Bengaluru"
WHERE NAME = "B";

SELECT * FROM Students;

UPDATE Students
SET City = "Vijayapura"
WHERE NAME = "D";

# TASKS:
# Try to update multiple records for multiple column
# Try to delete multiple records
# Try to explore aggregate functions
# Try to explore what are clauses and what is the use of clause and work on the clauses.


























