CREATE TABLE employee
(
 Emp_ID INT PRIMARY KEY,
 Name VARCHAR(50),
 Dept_ID INT
);

CREATE TABLE Dept
(
 Dept_ID INT PRIMARY KEY,
 Dept_Name VARCHAR(50)
);

INSERT INTO employee VALUES
(1, "Vishal", 101),
(2, "Aditya", 102),
(3, "Teja", NULL),
(4, "Priya", 103);

INSERT INTO Dept VALUES
(101, "HR"),
(102, "Finance"),
(103, "IT"),
(104, "Marketing");

# INNER JOIN
SELECT Emp_ID,Name,Dept_Name FROM employee
INNER JOIN Dept
ON Employee.Dept_ID = Dept.Dept_ID;

# LEFT JION
SELECT * FROM employee
LEFT JOIN Dept
ON employee.Dept_ID = Dept.Dept_ID;

# RIGHT JOIN
SELECT * FROM employee
RIGHT JOIN Dept
ON Employee.Dept_ID = Dept.Dept_ID;

# CROSS JOIN 
SELECT * FROM employee
CROSS JOIN Dept;

# Sub Queries:
SELECT * FROM customers;

SELECT * FROM orders;

SELECT customerNumber FROM orders;  # These are the customers who placed the order?

# How to get customer details of the people who placed the order?
SELECT * FROM customers
WHERE customerNumber IN (SELECT customerNumber FROM orders);

SELECT DISTINCT(status) FROM orders;

# Can u please get the customer details of the customers who had dispute?
select * from customers
where customerNumber in (select customerNumber 
from orders where status ='Disputed');

SELECT customerNumber FROM orders
WHERE status = "Disputed";

# Customer details of the customers who had dispute
SELECT * FROM customers
WHERE customerNumber IN (SELECT customerNumber FROM orders
                          WHERE status = "Disputed");
                          
                          
                          
USE Datamites;                          

CREATE TABLE employee
(
 Emp_ID INT PRIMARY KEY,
 Name VARCHAR(50),
 Email VARCHAR(50) UNIQUE,
 Age INT CHECK (Age > 18),
 Place VARCHAR(50) DEFAULT "Bangalore"
);

SELECT * FROM employee;

INSERT INTO employee VALUES
(1,"Anil","anil@gmail.com",19, "Mysore");

INSERT INTO employee(Emp_ID,Name,Email,Age) VALUES
(2,"Anil","anil_Statistician@gmail.com",20);

INSERT INTO employee(Emp_ID,Name,Email,Age) VALUES
(NULL,"Anil","anil_data scientist@gmail.com",20);

INSERT INTO employee(Emp_ID,Name,Email,Age) VALUES
(3,"Anil",NULL,20);

INSERT INTO employee(Emp_ID,Name,Email,Age) VALUES
(4,"Anil",NULL,20);

SELECT * FROM Employee;











